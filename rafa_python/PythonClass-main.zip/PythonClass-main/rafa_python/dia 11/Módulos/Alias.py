from os import system
import Saudações as sd
system("cls")

sd.bom_dia()
sd.boa_noite()