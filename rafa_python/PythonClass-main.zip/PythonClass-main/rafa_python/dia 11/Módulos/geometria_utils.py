PI = 3.14159

def area_circulo(raio):
    a = PI * (raio ** 2) 
def area_retangulo(base, altura):
    a = base * altura