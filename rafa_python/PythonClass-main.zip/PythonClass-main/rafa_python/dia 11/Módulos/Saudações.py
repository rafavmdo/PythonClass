from os import system
system("cls")

def bom_dia():
    print("Bom dia!")
def boa_noite():
    print("Boa noite!")