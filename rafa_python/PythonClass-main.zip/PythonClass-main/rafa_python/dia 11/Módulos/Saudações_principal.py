from os import system
import Saudações
system("cls")

Saudações.bom_dia()
Saudações.boa_noite()