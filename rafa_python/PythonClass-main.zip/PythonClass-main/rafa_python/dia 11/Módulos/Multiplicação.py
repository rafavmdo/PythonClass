from os import system
system("cls")

def multiplicação(a, b):
    print(f"{a} x {b} = {a * b:.2f}")

def divisão(a, b):
    print(f"{a} / {b} = {a / b:.2f}")