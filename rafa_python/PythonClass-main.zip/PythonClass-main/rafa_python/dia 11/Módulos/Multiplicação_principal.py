from os import system
import Multiplicação
import random
system("cls")

Multiplicação.multiplicação(random.randint(1, 50), random.randint(1, 50))
Multiplicação.divisão(random.randint(1, 50), random.randint(1, 50))
