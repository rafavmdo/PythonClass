def maior_numero(lista):
    return max(lista)

dinheiro = 41.00
print(f"{dinheiro:.2f}".replace(".", ","))