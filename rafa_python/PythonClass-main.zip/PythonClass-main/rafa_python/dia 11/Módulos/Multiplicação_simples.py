from os import system
from Multiplicação import multiplicação
system("cls")

multiplicação(8, 7)