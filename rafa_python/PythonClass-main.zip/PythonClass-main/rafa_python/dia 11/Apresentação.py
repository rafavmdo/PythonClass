from os import system
system("cls")

def apresentacao(nome, idade):
    print(f"Olá meu nome é {nome}, e eu tenho {idade} anos.")

apresentacao("Kenneth", 16)
