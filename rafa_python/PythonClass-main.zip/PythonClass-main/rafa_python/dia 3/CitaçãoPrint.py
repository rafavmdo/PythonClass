from os import system
system("cls")

print("Ele disse: \"Conhece-te a ti mesmo.\"")