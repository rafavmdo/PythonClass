from os import system
system("cls")

print("=========================\nMÁQUINA DE REFRIGERANTES\n\tDO SENAI\n=========================\n\n1 - Coca-Cola\t - R$ 5,00\n2 - Pepsi\t - R$4,50\n3 - Guaraná\t - R$ 4,00\n4 - Fanta Uva\t - R$ 3,00\n5 - Sprite\t - R$ 3,00\n6 - Coca-Zero\t - R$ 5,00\n\n=========================")
