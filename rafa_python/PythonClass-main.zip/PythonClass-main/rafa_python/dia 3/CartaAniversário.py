from os import system
system("cls")

print("\tCartão de Aniversário!\nOlá maria eduarda, espero que esteja bem.\U0001F601\nGostaria de desejar-lhe um feliz aniversário,\ndesde então agradeço pelos momentos que passei\ncom você e espero que tudo dê certo em sua vida! \U0001F970\n\nAtenciosamente, Kenneth.")