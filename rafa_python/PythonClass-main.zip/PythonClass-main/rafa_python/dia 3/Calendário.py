from os import system
system("cls")

print("Setembro\n\nDom\tSeg\tTer\tQua\tQui\tSex\tSab\n---------------------------------------------------")
print("\t", end ="")
print(1, 2, 3, 4, 5, 6, sep="\t")
print(7, 8, 9, 10, 11, 12, 13, sep="\t")
print(14, 15, 16, 17, 18, 19, 20, sep="\t")
print(21, 22, 23, 24, 25, 26, 27, sep="\t")
print(28, 29, 30, sep="\t")