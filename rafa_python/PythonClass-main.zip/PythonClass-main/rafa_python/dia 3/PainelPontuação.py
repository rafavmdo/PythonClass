from os import system
system("cls")
print("Na partida de hoje, o jogador {} marcou {} gols!".format("Pelé", 3))