# Exemplo 1: Calculando a área de um quadrado (lado²)
lado = 8
area = lado ** 2 # O mesmo que 8 * 8
print(f"A área de um quadrado com lado {lado} é {area}.") # Saída: 64