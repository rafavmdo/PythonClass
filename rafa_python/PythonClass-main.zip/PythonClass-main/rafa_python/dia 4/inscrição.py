from os import system
system("cls")

inscrição_confirmada = True

if inscrição_confirmada == True :
    print("Status da Inscrição (Confirmada?): Confirmada")

else:
    print("Status da Inscrição (Confirmada?): não confirmada")