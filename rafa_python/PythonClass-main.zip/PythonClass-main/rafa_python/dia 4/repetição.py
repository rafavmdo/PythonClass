from os import system
system("cls")

palavra = input("Digite uma palavra: ")
quantidade = int(input("Quantidade de vezes para ser repetida: "))

print(palavra * quantidade)